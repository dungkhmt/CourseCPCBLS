package khmtk60.miniprojects.multiknapsackminmaxtypeconstraints;

import localsearch.model.LocalSearchManager;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalSearchManager mgr = new LocalSearchManager();
		mgr.close();
	}

}
